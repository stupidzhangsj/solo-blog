title: Nacos 集群服务搭建踩坑记录
date: '2019-07-16 17:55:39'
updated: '2019-07-16 17:55:39'
tags: [Nacos]
permalink: /articles/2019/07/16/1563270939305.html
---
![](https://img.hacpai.com/bing/20180901.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

前言: 因为了解到Eureka2.0及其部分组件闭源的消息, 项目架构选型时，注册中心组件选择了Nacos作为项目的注册中心，而我负责服务使用的Nacos服务的搭建。  

本文所使用的是替换Eureka的Nacos,至于nacos是什么,想必看到本文的朋友应该都了解,不了解的可以看[这里](https://nacos.io/zh-cn/docs/what-is-nacos.html)。

在搭建的过程中遇到了不少问题，下面整理一些不是很常见的问题，有不对的地方，还请读者指出。
# 安装 Nacos

nacos 的基本安装使用也很简单,这里推荐查看 `程序猿DD` 的文章, 对部署等操作列举的清晰明了:
[使用Nacos实现服务注册与发现](http://blog.didispace.com/spring-cloud-alibaba-1/)

# 单机启动问题

在进行 Nacos 部署的时候后,如果是启动存在问题的可以看看以下方案:
[Nacos部署中的一些常见问题汇总](http://blog.didispace.com/nacos-faqs/)

# Nacos集群问题

这里我主要提一下我在集群中所遇到的主要问题:

```
code:503 msg: server is STARTING now, please try again later!
```
该问题分为两个类别:

## 同一网段

**Nacos集群时在 nacos/conf/cluster.conf 文件中配置的所有节点都是使用同一网段的内网ip (注意是同一网段)**


> 服务器: 三台同一内网的服务器

```java
[root@dpl ~]# vim /usr/local/nacos/conf/cluster.conf
#it is ip
#example
172.16.xx.29:8848
172.16.xx.30:8848
172.16.xx.31:8848
```
以上使用内网的三台 Nacos 服务进行集群, 注意是内网,内网,内网 !

**问题描述:**
按照官网文档修改了cluster.conf,添加了三台服务的IP(172.XX.XX.29:8848, 172.XX.XX.30:8848,172.XX.XX.31:8848)，启动 nacos 服务时报错。
这种情况此时启动服务应用进行服务注册，发现报如下错误：

```java
java.lang.IllegalStateException: failed to req API:/nacos/v1/ns/instance after all servers([172.16.xx.29:80]) tried
        at com.alibaba.nacos.client.naming.net.NamingProxy.reqAPI(NamingProxy.java:335)
        at com.alibaba.nacos.client.naming.net.NamingProxy.reqAPI(NamingProxy.java:267)
        at com.alibaba.nacos.client.naming.net.NamingProxy.registerService(NamingProxy.java:167)
        at com.alibaba.nacos.client.naming.NacosNamingService.registerInstance(NacosNamingService.java:170)
        at org.springframework.cloud.alibaba.nacos.registry.NacosServiceRegistry.register(NacosServiceRegistry.java:56)
        at org.springframework.cloud.alibaba.nacos.registry.NacosServiceRegistry.register(NacosServiceRegistry.java:29)
```
就算不报该错误的话, 这时 nacos 服务的控制台能够访问, 在进行注册服务的时候也无法注册, 会出现标题出现的问题

```java
code:503 msg: server is STARTING now, please try again later!
```

然而这个时候我们查看 naming-raft.log 文件查看日志, 发现
```java
2019-05-15 00:02:00,000 WARN [IS LEADER] no leader is available now!
```

从 [Nacos集群模式下服务无法注册](https://www.wandouip.com/t5i92492/) 这篇文章的到一定的帮助, 并解决该问题.
深层的原因： 在大多数Linux操作系统中，都是以/etc/hosts中的配置查找主机名的，而 Java 的InetAddress.java 调用 InetAddressImpl.java 的 public native String getLocalHostName() throws UnknownHostException; 
来获取本地主机名，Java 的这个方法是 native 的，是本地系统的一个实现，此时根据本地/etc/hostname文件中的机器名来获取本机 IP，然而这个 IP 并不是这台机器的内网 IP，所以这篇文章是通过修改本机名称和本机IP来解决 .

## 不同网段

**Nacos集群时在 nacos/conf/cluster.conf 文件中配置的所有节点是使用的不同网段的ip**

> 服务器: 三台不同网段的服务器
> 这里我使用一台腾讯云,两台阿里云, 都不在同一内网中

```java
#it is ip
#example
59.xx.xxx.242:8848
120.xx.x.129:8848
148.xx.xx.37:8848
```

云服务器一般都会提供外网和内网的 ip, 访问外网 ip 时会指向对应的内网 ip 来访问到该服务器, 由于 nacos 集群内部是指定的使用网卡ip地址来进行通信,但是由于三台服务器各自的内网 ip 不在同一网段, 所以造成无法通信, 也会造成以下问题

注册服务:

```
code:503 msg: server is STARTING now, please try again later!
```

naming-raft.log 日志:

```
2019-05-15 00:02:00,000 WARN [IS LEADER] no leader is available now!
```

这个问题找了很久, 查询资料后发现可以通过启动文件设置 ip 地址的参数来自己指定使用的 ip 地址

``` java
private static String getHostAddress() {
        String address = System.getProperty("nacos.server.ip");
        if (StringUtils.isNotEmpty(address)) {
            return address;
        } else {
            address = "127.0.0.1";
        }
		...
}
```
这时只要修改启动参数, 设置本机 ip 地址就可以了
修改 nacos/bin/startup.sh 文件
找到 JVM Configuration 这部分, 在集群参数里增加 -Dnacos.server.ip=xx

```
#=================================================================================
# JVM Configuration
#================================================================================

# 单机模式对应的启动参数
if [[ "${MODE}" == "standalone" ]]; then
    JAVA_OPT="${JAVA_OPT} -Xms512m -Xmx512m -Xmn256m"
    JAVA_OPT="${JAVA_OPT} -Dnacos.standalone=true"
else
# 集群模式对应的启动参数
    JAVA_OPT="${JAVA_OPT} -server -Xms2g -Xmx2g -Xmn1g -XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=320m"
    JAVA_OPT="${JAVA_OPT} -XX:-OmitStackTraceInFastThrow -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${BASE_DIR}/logs/java_heapdump.hprof"
    JAVA_OPT="${JAVA_OPT} -XX:-UseLargePages"

# 新增以下参数设置本机ip地址
    JAVA_OPT="${JAVA_OPT} -Dnacos.server.ip= 服务器的ip"

fi
```

# 服务器的 JDK 版本低于1.8
**Nacos 要求服务器的jdk版本高于1.8**
当jdk版本不满足要求时；我们可以这样做
```java
1：可以升级服务器的jdk；
2: 指定jdk的目录
```
	
下面演示的是怎么指定自己的jdk路径
``` 
#===========================================================================================
# JVM Configuration
#===========================================================================================

# 系统默认的 java 路径
#[ ! -e "$JAVA_HOME/bin/java" ] && JAVA_HOME=$HOME/jdk/java
#[ ! -e "$JAVA_HOME/bin/java" ] && JAVA_HOME=/usr/java
#[ ! -e "$JAVA_HOME/bin/java" ] && JAVA_HOME=/opt/taobao/java
#[ ! -e "$JAVA_HOME/bin/java" ] && unset JAVA_HOME

# 修改为自己指定的jdk
[ ! -e "$JAVA_HOME/bin/java" ] && JAVA_HOME= 修改的jdk 路径

```
---

![enter description here](https://upload-images.jianshu.io/upload_images/10123486-d45fa62009ec8c21.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

多学一点知识，就可以少写一行代码